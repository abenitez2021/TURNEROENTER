The works contained in this archive were created by amCharts (https://www.amcharts.com/)
and is licensed under Creative Commons Attribution 4.0 International Public License:

https://creativecommons.org/licenses/by/4.0/

If in doubt, email amCharts at contact@amcharts.com